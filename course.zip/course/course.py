#encoding=utf-8
from pandas import DataFrame
import pandas as pd
import numpy as np
from numpy import *
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
df=pd.read_csv('result2.csv',dtype={"mxPH": np.float64},)
import math
import time
import csv
#print df.season.value_counts()
#print df.Riversize.value_counts()
#print df.Waterspeed.value_counts()
#print df.describe()
#print df.info()
#print df.describe()
#统计标称属性中每个取值的频数

#print df2
#plt.show()
#df1['summer']=df.season[df.season=='summer']
#df1.boxplot()
'''
print df.mnO2.value_counts()

print df.season.value_counts()
print df.Riversize.value_counts()
print df.waterspeed.value_counts()


'''
#用众数填补缺失值

a=df.mxPH.mode()
df['mxPH'][df.mxPH.isnull()]=a[0]
a=df.mnO2.mode()
df['mnO2'][df.mnO2.isnull()]=a[0]
a=df.CI.mode()
df['CI'][df.CI.isnull()]=a[0]
a=df.NO3.mode()
df['NO3'][df.NO3.isnull()]=a[0]
a=df.NH4.mode()
df['NH4'][df.NH4.isnull()]=a[0]
a=df.oPO4.mode()
df['oPO4'][df.oPO4.isnull()]=a[0]
a=df.PO4.mode()
df['PO4'][df.PO4.isnull()]=a[0]
#a=df.Chia.mode()
#利用数据对象之间的相关性填补空缺值
#通过计算数据'mxPH','mnO2','CI', 'NO3', 'NH4', 'oPO4','PO4'之间的距离，选择距离最小那条属性的CHia值来填补空缺值。
'''
Chia_df=df[['Chia','mxPH','mnO2','CI', 'NO3', 'NH4', 'oPO4','PO4']]
x_notnull=Chia_df.loc[(df.Chia.notnull())].values
x_null=Chia_df.loc[(df.Chia.isnull())].values
print x_null.shape

for m in range(0,x_null.shape[0]):
    a=sqrt(sum(power(x_null[m,1:]-x_notnull[0,1:],2)))
    for n in range(0,x_notnull.shape[0]):
        #sqrt(sum(power(vector2 - vector1, 2)))
        distance=sqrt(sum(power(x_null[m,1:]-x_notnull[n,1:],2)))
        if distance<a:
            a=distance
            k=n
        #print x_null[m,:]-x_notnull[n,:]
        #if abs(x_null[m,:]-x_notnull[n,:])<10:
            #x_null[m,0]=x_notnull[n,0]
    x_null[m,0]=x_notnull[k,0]
df.loc[ (df.Chia.isnull()), 'Chia' ] =x_null[:,0] 
columns=['mxPH','mnO2','CI','NO3','NH4','oPO4','PO4','Chia','a1','a2','a3','a4','a5','a6','a7']
df.hist(column=columns,layout=(3,5),grid=False)
#plt.show()
df.to_csv('result.csv')
'''
'''
print df
name = "rfc" + str(int(time.time())) + ".csv"
result_file = open("./" + name, "wb")
open_file_object = csv.writer(result_file)
#open_file_object.writerow(['mxPH','mnO2','CI','NO3','NH4','oPO4','PO4','Chia','a1','a2','a3','a4','a5','a6','a7'])
#open_file_object.writes(df)
'''


    
        
        



#使用随机森林对Chia缺失值进行填补

Chia_df = df[['Chia','mxPH','mnO2','CI', 'NO3', 'NH4', 'oPO4','PO4']]
X = Chia_df.loc[ (df.Chia.notnull()) ].values[:, 1::]
y = Chia_df.loc[ (df.Chia.notnull()) ].values[:, 0]
    
rtr = RandomForestRegressor(n_estimators=2000, n_jobs=-1)
rtr.fit(X, y)
        
predictedAges = rtr.predict(Chia_df.loc[ (df.Chia.isnull()) ].values[:, 1::])
df.loc[ (df.Chia.isnull()), 'Chia' ] = predictedAges 
#print df.info()
columns=['mxPH','mnO2','CI','NO3','NH4','oPO4','PO4','Chia','a1','a2','a3','a4','a5','a6','a7']
df.hist(column=columns,layout=(3,5),grid=False)
plt.show()
df.to_csv('finaresult.csv')



#fig=plt.figure(figsize=(20,12),dpi=100)

#直方图
#绘画总的直方图
'''
columns=['mxPH','mnO2','CI','NO3','NH4','oPO4','PO4','Chia','a1','a2','a3','a4','a5','a6','a7']
df.hist(column=columns,layout=(3,5),grid=False)
plt.show()
'''
#单个的直方图
'''
df1=df[['mxPH']]
df1.hist(stacked=True)
df2=df[['mnO2']]
df2.hist(stacked=True)
df3=df[['CI']]
df3.hist(stacked=True)
df4=df[['NO3']]
df4.hist(stacked=True)
df5=df[['NH4']]
df5.hist(stacked=True)
df6=df[['oPO4']]
df6.hist(stacked=True)
df7=df[['PO4']]
df7.hist(stacked=True)
df8=df[['Chia']]
df8.hist(stacked=True)
df9=df[['a1']]
df9.hist(stacked=True)
df10=df[['a2']]
df10.hist(stacked=True)
df11=df[['a3']]
df11.hist(stacked=True)
df12=df[['a4']]
df12.hist(stacked=True)
df13=df[['a5']]
df13.hist(stacked=True)
df14=df[['a6']]
df14.hist(stacked=True)
df15=df[['a7']]
df15.hist(stacked=True)
#df2.hist(stacked=True)
plt.show()
'''


#盒图
'''
df1=df[['mxPH']]
df1.boxplot()

df2=df[['mnO2']]
df2.boxplot()

df3=df[['CI']]
df3.boxplot()

df4=df[['NO3']]
df4.boxplot()

df5=df[['NH4']]
df5.boxplot()

df6=df[['oPO4']]
df6.boxplot()

df7=df[['PO4']]
df7.boxplot()

df8=df[['Chia']]
df8.boxplot()

df9=df[['a1']]
df9.boxplot()

df10=df[['a2']]
df10.boxplot()

df11=df[['a3']]
df11.boxplot()

df12=df[['a4']]
df12.boxplot()

df13=df[['a5']]
df13.boxplot()

df14=df[['a6']]
df14.boxplot()

df15=df[['a7']]
df15.boxplot()
plt.show()
'''




#条件盒图
'''
df1=DataFrame()
df2=DataFrame()
df3=DataFrame()
df4=DataFrame()

df1['spring']=df.a1[df.season=='spring']
df2['summer']=df.a1[df.season=='summer']
df3['autumn']=df.a1[df.season=='autumn']
df4['winter']=df.a1[df.season=='winter']
df5=pd.concat([df1,df2,df3,df4],axis=1)
#df1=DataFrame(df1)
print df5.info()
df5.boxplot()
plt.title('a1 with season')
plt.show()

df1['low']=df.a1[df.Waterspeed=='low']
df2['medium']=df.a1[df.Waterspeed=='medium']
df3['high']=df.a1[df.Waterspeed=='high']

df4=pd.concat([df1,df2,df3],axis=1)
df4.boxplot()
plt.show()
'''